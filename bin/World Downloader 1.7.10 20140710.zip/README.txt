WORLD DOWNLOADER v2
------------------------------
Official forum thread and downloads are here:

http://www.minecraftforum.net/topic/1444862-


INSTALLATION (manual way)
------------------------------
MagicLauncher is highly recommended. Otherwise, the following steps will get you there too.

1. Make a new Minecraft version by copying an existing folder from 'versions' folder and renaming
   (e.g. Copy 1.6.4 to 1.6.4.wdl) SEE BELOW, How to find your Minecraft versions folder
2. In the new folder, rename the .jar and .json files with the same name as the folder (add .wdl)
3. Edit the .json file to add the .wdl in the "id:" field
4. Open the minecraft.jar with an archive tool like WinRAR. *** DO NOT EXTRACT THE FILES ***
5. Put the class files you just downloaded in there. Overwrite if necessary.
6. Delete the META-INF folder if it exists in the jar file.
7. Close the archive and save if asked. 
8. Start the launcher and make a new profile, selecting the new version folder you just made (e.g. 1.6.4.wdl)


How to find your Minecraft versions folder:

* Windows by entering %APPDATA%\.minecraft\versions in an Explorer window or in the start->run dialog.

* Linux by opening ~/.minecraft/versions/ in a file manager of your choice.

* Mac OS X by opening Library/Application Support/minecraft/versions in Finder.
